import Select from 'react-select';
import { useState } from 'react';
import Icon from '@mui/material/Icon';
import SendIcon from "@mui/icons-material/Send";
import Stack from "@mui/material/Stack";
import { useInterval } from "../hooks/use-interval";
import { FormControl, TextField, Button, Card, MenuItem, InputLabel } from '@mui/material';
import "./chat.css";


export const ChatTemp = () => { 

    const [chats, setChats] = useState([{id: '', name:''}]);
    const [messages, setMessages] = useState([{chatId: "", text: "", username: "", isoDate: "", id: ""}]);
    const [chatId, setChatId] = useState('b23ae}22b-3d26-461d-a11d-08c5aa19bd3c');
    const[newChat, setNewChat] = useState('');
    const[user, setUser] = useState('');
    const [newMsg, setNewMsg] = useState('');
   
    useInterval(
        (params) => {
            const chatId = params[0];      
            chats = fetch("https://z36h06gqg7.execute-api.us-east-1.amazonaws.com/chats")
            .then((response) => response.json())
            .then((data) => setChats(data.Items));
        },
        1000
    );
    
    useInterval(
        (params) => {
        const chatId = params[0]; 
           fetch(`https://z36h06gqg7.execute-api.us-east-1.amazonaws.com/chats/${chatId}/messages`)
             .then((response) => response.json())
             .then((data) => {
               setMessages(data.Items);
               console.log("message" + data.Items);
             });
         },
          1000
       );

    const handleChatChange = selectedChat => {

        setChatId(selectedChat.id);
        console.log("chat id: " + selectedChat.name);
    }

    function addUser(){

    }

    function addMessage () {
        const msg = {text: newMsg, username: user};

        fetch(`https://z36h06gqg7.execute-api.us-east-1.amazonaws.com/chats/${chatId}/messages`, {
            method: "PUT",
            headers: {
             "Content-Type": "application/json", // tells REST that we will send the body data in JSON format
            },
            body: JSON.stringify(msg),
        });
    }

    function addChat(){
        console.log("add chat: " + newChat);
        
        fetch('https://z36h06gqg7.execute-api.us-east-1.amazonaws.com/chats', {
            method: "PUT",
            headers: {
             "Content-Type": "application/json", // tells REST that we will send the body data in JSON format
            },
            body: JSON.stringify(newChat),
        });
    }

    return(
        <div>
            <link
             rel="stylesheet"
             href="https://fonts.googleapis.com/icon?family=Material+Icons"
            />
            <div className="chatRoom">
            <h1>Chat Room</h1>
            <div className="message">
            <Stack direction="row" spacing={1}>
            <ChatList chats={chats} handleChatChange = {handleChatChange}/>                          
                <TextField id="outlined-basic" variant="outlined" size= "small"
                 label = "Enter New Chat"
                onChange={(event) => setNewChat(event.target.value)}
                />
                <Button onClick={addChat}>
                <Icon fontSize= 'large' >add_circle</Icon></Button>
                <TextField id="outlined-basic" variant="outlined" size= "small"
                 label = "Enter Username"
                onChange={(event) => setUser(event.target.value)}
                />
                <Button onClick={addUser}>
                <Icon fontSize= 'large' >add_circle</Icon></Button>  
            </Stack>
             
             {/* <Message messages={messages} currChat={currChat.id} />*/}
             
                {messages.map((message) => (<Message text={message.text} username={message.username}/>))}
            </div>
                <Stack direction="row" spacing={2}>
                <TextField id="outlined-basic" variant="outlined" size= "small"
                 placeholder = "Enter Message"
                onChange={(event) => setNewMsg(event.target.value)}
                />
                <Button variant="contained" onClick={addMessage} endIcon={<SendIcon />}>Send</Button>
                </Stack>
            </div>
        </div>
    );
}
const Message = (props) => {

    return(<Card>{props.username} : {props.text}</Card>);
}


const ChatList = (props) => {
    
    return(
      <FormControl>
      <Select
      placeholder={"Select Chat Room"} 
      onChange ={props.handleChatChange}
      options ={props.chats}
      value= {props.chats.id}
      >
    </Select>
    </FormControl>
        
    );

}


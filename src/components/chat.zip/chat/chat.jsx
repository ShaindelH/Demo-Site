import Select from 'react-select';
import { useState } from 'react';
import { useInterval } from "../hooks/use-interval";
import { FormControl, MenuItem } from '@mui/material';

export const Chat = () => { 

    const [chats, setChats] = useState([{id: '', name:''}]);
    const [messages, setMessages] = useState([{}]);
    const [chatId, setChatId] = useState();

    useInterval(
        () => {
            chats = fetch("https://z36h06gqg7.execute-api.us-east-1.amazonaws.com/chats")
            .then((response) => response.json())
            .then((data) => {setChats(data.Items);}); 
        },
        2000
    );
    
    useInterval(
         () => {
           fetch(`https://z36h06gqg7.execute-api.us-east-1.amazonaws.com/chats/${chatId}/messages`)
             .then((response) => response.json())
             .then((data) => {
               setMessages(data.Items);
             });
         },
          7000, 
         chatId
       );;
      
    const handleChatChange = selectedChat => {

        setChatId(selectedChat.id);
        console.log("chat id: " + chatId);
    }
    messages.map(message => {console.log(message.text)});
    return(
        <table className="chatRoom">
            <tbody>
                <tr>
                    <th>Chat Room</th>
                </tr>
                <tr>
                    <td><ChatList chats={chats} handleChatChange = {handleChatChange} /></td>
                </tr>
                <tr>
                    <td>chat id: {chatId}</td> 
                    
                </tr>
                {messages.map((message) => (<Message text={message.text} username={message.username}/>))}
            </tbody>
        </table>
    );
}

const Message = (props) => {

    return(<tr><td>{props.username} : {props.text}</td></tr>);
}

const ChatList = (props) => {
    //options ={props.chats}
    //{props.chats.map((chat) => <MenuItem value={chat.id}>{chat.name}</MenuItem>)}      
    return(
        <FormControl>
        <Select 
        placeholder={"Chat Room"} 
        onChange ={props.handleChatChange}
        options ={props.chats}
        >      
   </Select>
   </FormControl>
            
        
    );
}

